<section>
    <div class="container">
        <div class="row">
<?php
   include("unit/kategori_unit.php");
?>
            <div class="col-sm-9">
                <div class="blog-post-area">
                    <h2 class="title text-center"> Informasi Tanaman</h2>
                    <?php
                    $batas   = 3;
                    $halaman = @$_GET['halaman'];
                    if(empty($halaman)){
                     $posisi  = 0;
                     $halaman = 1;
                    }
                    else{ 
                      $posisi  = ($halaman-1) * $batas; 
                    }


                    $qblog =" SELECT * FROM t_informasi  ORDER BY tanggal DESC, jam DESC LIMIT $posisi,$batas";
                    $rblog = mysqli_query($mysqli, $qblog);
                    while($dblog = mysqli_fetch_array($rblog)){
                    ?>
                    <div class="single-blog-post">
                        <h3><?php echo $dblog['judul'] ?></h3>
                        <div class="post-meta">
                            <ul>
                                <li><i class="fa fa-clock-o"></i><?php echo $dblog['jam'] ?></li>
                                <li><i class="fa fa-calendar"></i><?php echo $dblog['tanggal'] ?></li>
                            </ul>
                        </div>
                        <a href="">
                                <img src="gambar/<?php echo $dblog['gambar_info'] ?>" style="position: relative;   height: 200px" alt="">
                        </a>
                        <p><?php $kalimat = strtok(nl2br($dblog['isi'])," ");
                                for($i=1; $i<=25; $i++) {
                                echo $kalimat;
                                echo " ";
                                $kalimat = strtok(" ");
                                }
                         ?></p>
                        <a href="mainapp.php?unit=detailblog_unit&kd_info=<?php echo $dblog['kd_info'] ?>"  type="button" class="btn btn-default get" href="" ><i  class="fa fa-eye"></i> Baca</a>
                    </div>
                    <br><br><br>
                    <?php
                    }
                    ?>
                    
                    <div class="pagination-area">
                        <ul class="pagination">
                            <?php
                            $query2     = mysqli_query($mysqli, "select * from t_informasi");
                            $jmldata    = mysqli_num_rows($query2);
                            $jmlhalaman = ceil($jmldata/$batas);
                            
                            for($i=1;$i<=$jmlhalaman;$i++)
                            if ($i != $halaman){
                             echo " <li><a href=\"mainapp.php?unit=bloglist_unit&halaman=$i\">$i</a></li>  ";
                            }
                            else{ 
                             echo " <li><a>$i</a></li>  "; 
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    
    </div>
</section>
