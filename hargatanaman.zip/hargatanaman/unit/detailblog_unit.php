<?php
$kd_info =$_GET ['kd_info'];
$qblog =" SELECT    *  FROM   t_informasi 
  WHERE
   
  
   kd_info = '$kd_info'
  ORDER BY
  tanggal DESC, jam DESC
";
$rblog = mysqli_query($mysqli, $qblog);
$dblog = mysqli_fetch_assoc($rblog);
?>
<section>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="blog-post-area">
                    <h2 class="title text-center">Informasi Tanaman</h2>
                    <div class="single-blog-post">
                        <h3><?php echo $dblog['judul'] ?></h3>
                        <div class="post-meta">
                            <ul>
                                <li><i class="fa fa-clock-o"></i> <?php echo $dblog['jam'] ?></li>
                                <li><i class="fa fa-calendar"></i> <?php echo $dblog['tanggal'] ?></li>
                            </ul>
                            </div>
                            <a href="">
                                    <img src="gambar/<?php echo $dblog['gambar_info'] ?>" style="position: relative; height: 400px"  alt="">
                            </a>
                            <p><?php $kalimat = strtok(nl2br($dblog['isi'])," ");
                                for($i=1; $i<=100000; $i++) {
                                echo $kalimat;
                                echo " ";
                                $kalimat = strtok(" ");
                                }
                         ?></p> <br>
                                   
                            
                        </div>
                    </div><!--/blog-post-area-->
                    <div class="rating-area">
                        <ul class="ratings">
                            <li class="rate-this">KOMENTAR:</li>
                            <?php
                $kd_info =$_GET ['kd_info'];
                $qkategori =" SELECT * FROM t_komentar   WHERE kd_info = '$kd_info'";
                $rkategori = mysqli_query($mysqli, $qkategori);
                $dkategori= mysqli_num_rows($rkategori);
                $dskomentar = mysqli_query($mysqli, "SELECT * FROM t_komentar WHERE kd_komentar = '".$dkategori['kd_komentar']."'");
                $gskomentar = mysqli_fetch_assoc($dskomentar);
                echo "<li class='color'>( $dkategori komentar)</li>";
                ?> 
                        </ul>
                    </div><!--/rating-area-->
                    <br>

                        <div class="response-area">
                            <?php
                            $kd_komentar =$_GET ['kd_info'];
                            $qkomentar =" SELECT * FROM t_komentar WHERE kd_info = '$kd_komentar' ";
                            $rkomentar = mysqli_query($mysqli, $qkomentar);
                            while($dkomentar = mysqli_fetch_assoc($rkomentar)){
                                $dskomentar = mysqli_query($mysqli, "SELECT * FROM t_komentar WHERE kd_komentar = '".$dkomentar['kd_komentar']."'");
                                        $gskomentar = mysqli_fetch_assoc($dskomentar);
                                if($gskomentar['kd_komentar'] == $dkomentar['kd_komentar']){
                                        ?>
                            <ul class="media-list">
                                <li class="media">

                                    <div class="media-body">
                                        <ul class="sinlge-post-meta">
                                            <li><i class="fa fa-user"></i><?php echo $dkomentar['nama'] ?></li>
                                            <li><i class="fa fa-clock-o"></i><?php echo $dkomentar['jam'] ?></li>
                                            <li><i class="fa fa-calendar"></i><?php echo $dkomentar['tanggal'] ?></li>
                                        </ul>
                                            <p><?php echo $dkomentar['komentar'] ?></p>                 

                                    </div>
                                </li>
                                
                            </ul>	       
                            <?php
                            }
                            
                            }
                            ?>
                        </div><!--/Response-area-->

                        <div class="replay-box">
                            <div class="row">
<?php
                                if(isset($_POST['submit'])){
                                    $yname = $_POST['nama'];
                                    $yemail = $_POST['email'];
                                    $ykomentar = $_POST['komentartext'];

                                    if(!empty($yname) and !empty($yemail) and !empty($ykomentar)){
                                        $qsenddata = mysqli_query($mysqli, "INSERT INTO t_komentar (kd_info, komentar, tanggal, nama, email, jam) VALUE ('$kd_info', '$ykomentar', '".date('Y-m-d')."', '$yname', '$yemail', '".date('H:i:s')."')");
                                        if($qsenddata){
                                            echo "Komentar anda sudah terkirim.";
                                            ?><script type="text/javascript">alert("Komentar anda sudah terkirim.");setInterval(function(){ document.location=""; }, 1000);</script><?php
                                        }
                                        else{
                                            echo "Gagal mengirimkan komentar !";
                                        }
                                    }
                                    else{
                                        echo "Form tidak boleh kosong !";
                                    }
                                }
                            ?>
                                <form action="#" method="post" >
                                    <div class="col-sm-4">
                                        <h2>Masukan Komentar</h2>
                                        <div class="blank-arrow">
                                            <label>Nama</label>
                                        </div>
                                        <span>*</span>
                                            <input type="text" placeholder="Nama Kamu" name="nama">
                                        <div class="blank-arrow">
                                                <label>Email</label>
                                        </div>
                                        <span>*</span>
                                            <input type="email" placeholder="Email Kamu" name="email">
                                        <div class="blank-arrow">
                                        </div>
                                    </div>
                                    <div class="col-sm-8">
                                        <div class="text-area">
                                            <div class="blank-arrow">
                                                    <label>Komentar</label>
                                            </div>
                                            <span>*</span>
                                            <textarea name="komentartext" rows="8" placeholder="Masukan Komentar" ></textarea>
                                            <input  class="btn btn-primary" type="submit" name="submit" value="kirim" >
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div><!--/Repaly Box-->
                    </div>
                </div>
               
        </div>
</section>
