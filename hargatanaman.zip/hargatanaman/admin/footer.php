  <div class="space-20"></div>

  <div class="footer">
    <div class="footer-inner">
      <div class="footer-content">
        <span class="bigger-120">
         APLIKASI SISTEM INFORMASI HARGA TANAMAN PANGAN DAN HORTIKULTURA &copy; RIZKY RAHMAN 3101 1502 2779 (2020) 
        </span>
        |
       <!-- <span class="action-buttons">
          <a href="https://facebook.com/azmijr">
            <i class="ace-icon fa fa-instagram-square text-primary"></i> Adie
          </a>

          <a href="#">
            <i class="ace-icon fa fa-phone orange"></i> 081228289766
          </a>
        </span>-->
      </div>
    </div>
  </div>

  <a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
    <i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
  </a>
</div><!-- /.main-container -->

<!-- basic scripts -->

<!--[if !IE]> -->
<script src="../css/backend/js/jquery-2.1.4.min.js"></script>
<script type="text/javascript">
if('ontouchstart' in document.documentElement) document.write("<script src='../css/backend/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
</script>
<script src="../css/backend/js/bootstrap.min.js"></script>

<script src="../css/backend/js/jquery-ui.custom.min.js"></script>
<script src="../css/backend/js/jquery.ui.touch-punch.min.js"></script>

		
  <script src="../css/backend/js/gen_validatorv4.js" type="text/javascript"></script>
  <script src="../css/backend/js/inputmask.js"></script>
  <script src="../css/backend/tinymce/js/tinymce/tinymce.min.js"></script>
<!-- ace scripts -->
<script src="../css/backend/js/ace-elements.min.js"></script>
<script src="../css/backend/js/ace.min.js"></script>
   

		
		




