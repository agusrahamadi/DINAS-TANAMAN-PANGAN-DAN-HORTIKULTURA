<?php
   include("../admin/head.php");
?>
<?php
   include("../admin/navbar.php");
?> 
<div class="main-container ace-save-state" id="main-container">

<?php
    require_once('content.php'); 
?>
  